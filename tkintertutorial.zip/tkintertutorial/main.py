from tkinter import *


class Window(Frame):
    def __init__(self, master=None):
        Frame.__init__(self, master)
        self.master = master
        self.init_window()

    def init_window(self):
        # makes window and names it GUI
        self.master.title("GUI")
        self.pack(fill=BOTH, expand=1)
        # defines and places button
        # quitButton = Button(self, text="Quit", command=self.client_exit)
        # quitButton.place(x=0, y=0)
        # add menu
        menu = Menu(self.master)
        self.master.config(menu=menu)

        # add menu buttons
        file = Menu(menu)
        file.add_command(label='Save', command=self.client_exit)
        file.add_command(label='Exit', command=self.client_exit)
        menu.add_cascade(label='File', menu=file)

        # add second menu button
        edit = Menu(menu)
        edit.add_command(label='Undo')
        menu.add_cascade(label='Edit', menu=edit)

    # defines quit commmand
    def client_exit(self):
        exit()


root = Tk()
# defines window size
root.geometry("400x300")
app = Window(root)
root.mainloop()
